package com.company;

public class Main {

    public static void main(String[] args) {
	    Zvirata pes = new Zvirata("Hafan", 5, zvire.PES);
        Zvirata kocka = new Zvirata("Mnau", 1, zvire.KOCKA);
        Zvirata prase = new Zvirata("Chrochtak", 4, zvire.PRASE);

        System.out.println("Pes jménem " + pes.getJmeno() + ", věk " + pes.getVek() + " let, opravdu je to " + pes.getTyp());
        System.out.println("Kočka jménem " + kocka.getJmeno() + ", věk " + kocka.getVek() + " rok, opravdu je to " + kocka.getTyp());
        System.out.println("Prase jménem " + prase.getJmeno() + ", věk " + prase.getVek() + " roky, opravdu je to " + prase.getTyp());
    }
}
