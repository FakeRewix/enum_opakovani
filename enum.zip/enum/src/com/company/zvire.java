package com.company;

public enum zvire {
    PES,
    KOCKA,
    PRASE
}
