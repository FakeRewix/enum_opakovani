package com.company;

public class Zvirata {
    private String jmeno;
    private int vek;
    private zvire typ;

    public String getJmeno() {
        return jmeno;
    }

    public void setJmeno(String jmeno) {
        this.jmeno = jmeno;
    }

    public int getVek() {
        return vek;
    }

    public void setVek(int vek) {
        this.vek = vek;
    }

    public zvire getTyp() {
        return typ;
    }

    public void setTyp(zvire typ) {
        this.typ = typ;
    }

    public Zvirata(String jmeno, int vek, zvire typ) {
        this.jmeno = jmeno;
        this.vek = vek;
        this.typ = typ;
    }
}
